NOTE: This demo font is ONLY for PERSONAL USE. NO COMMERCIAL USE ALLOWED!
But any donation are very appreciated
Paypal account for donation :
paypal.me/MuhJunaid
If you need for COMMERCIAL USE, you can buy the license here :
https://juncreative.net/downloads/winston-andrews-script/


-If you need a custom license please contact us at
hello@juncreative.net
or contact me to my instagram ==> www.instagram.com/mjart96/
-Please visit our store for more amazing fonts :
https://juncreative.net

INDONESIA - MOHON DIBACA:
Halo, perlu diketahui bahwa font ini hanyak untuk penggunaan PERSONAL SAJA .
Tidak diperbolehkan untuk penggunaan KOMERSIL apapun kecuali anda membeli LISENSI-nya terlebih dahulu.
Lisensi bisa anda beli di :
https://juncreative.net/downloads/winston-andrews-script/

Apabila anda melanggar/menggunakan untuk kebutuhan komersil tanpa membeli lisensinya terlebih dahulu,
anda akan dikenakan biaya minimal Rp 25.000.000 (Dua Puluh Lima Juta Rupiah)

Terima kasih , mohon saling support ya :)